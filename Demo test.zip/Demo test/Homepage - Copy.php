<?php
/* Template Name: Homepage*/ 


?>

<?php get_header(); ?>
<?php
        if (!empty($_POST)) {
        global $wpdb;
            $table = form;
            $data = array(
                'name'    => $_POST['your-name'],
				'Email'    => $_POST['your-email'],
				
				'Phone'    => $_POST['tel']
				
            );
            $format = array(
                '%s','%s','%s','%s','%s','%s','%s'
            );
            $success=$wpdb->insert( $table, $data, $format );
            if($success){
				echo "<script>alert('New record created successfully !')</script>" ; 
			}
		}
		else   { ?>

	
	<?php }  ?>
	 <div class="row"> <!-- MAIN ROW START***** -->
         <div class="col-sm-8"> <!-- article columns -->
            <div class="row" style="margin-bottom: 30px;">
               <?php if (have_posts()) : while (have_posts()) : the_post();?> 
                 <div class='<?php echo 'col-xs-12 col-sm-6'; ?>'>
                 
                   <p><?php the_content(); ?></p>
                 </div>
              <?php endwhile; endif; ?>
             </div>
          </div> <!-- article columns end -->

          <div class="col-sm-4"> <!-- Sidebar Start-->
            <div class="row">
               <div class="col-xs-12 col-sm-12">
                              <div class="col-sm-12 blog-main">
<div id="primary" class="content-area">
		<form method="post" >
		<p><label> Your Name<br />
			<input type="text" class="form-control" onkeypress="return /[a-z]/i.test(event.key)"name="your-name" value="" size="40" required placeholder="First Name" /></label></p>
		<p><label> Your Email<br />
			<input type="email" class="form-control" name="your-email" value="" size="40"  placeholder="your-email" required pattern=".+@gmail.com"/></label></p>
		
		<p><label> Your Phone Number<br />
			<input type="text" name="tel" class="form-control"value="" size="40"maxlength="10" onkeypress='validate(event)'  placeholder="Mobile Number"required /></label></p>
	
		<p><input type="submit" value="Send" class="btn btn-info" /></p>
		</form>

		</main><!-- .site-main -->
	</div><!-- .content-area -->
	
	</div>
                </div>
            </div> 
          </div><!-- Sidebar End -->
       <div> <!-- MAIN ROW END -->
	   <script>
	function validate(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
	   </script>
	   
<?php //get_footer(); ?>