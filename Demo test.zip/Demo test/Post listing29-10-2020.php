<?php
/* Template Name: Post listing*/ 


?>

<?php get_header(); ?><br />
<div class="col-sm-8 blog-main">


<!-- /.blog-main -->

 


      <?php
 //  echo '<li><a href="#" data-slug="' . $cat->term_id . '" class="js-category-button btn btn-primary "style="margin:5px;">' . $cat->name .  ' ' . $cat->category_count .  '   </a></li>';
	// echo '<li class="list-group-item d-flex align-items-center"><a href="' . get_category_link( $cat->term_id ) . '" rel="bookmark"><i class="fa fa-chevron-right" aria-hidden="true"></i>' . $cat->name . '<span>' . $cat->category_count . '</span></a></li>';
       
        $cat_args = array(
          'orderby'     => 'name',
          'order'       => 'ASC',
          'hide_empty'  => 1
        );

echo'<select >
  	<option value="">Any Program</option>';
        $cats = get_categories($cat_args);
  foreach($cats as $cat){
			?>
        <option value= <?php echo $cat->term_id ?> > 
					        	<?php  echo '<li><a href="#" data-slug="' . $cat->term_id . '" class="js-category-button btn btn-primary "style="margin:5px;">' . $cat->name .  ' ' . $cat->category_count .  '   </a></li>'; ?>
					        </option>
	<?php	}
echo ' </select>';
      ?>
      <div class="the-news" >

  <?php
  $taxonomy = 'category';
    $args = array( 'category' => $taxonomy, 'post_type' =>  'post' ,'post_status' => 'publish',); 
    $postslist = get_posts( $args );    
    foreach ($postslist as $post) :  setup_postdata($post); 
    ?>  
    <p><a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a></p> 
    <?php the_excerpt(); ?>  
    <?php endforeach; ?> 
    </div>

	
  
  
</div>
  

<form action="<? bloginfo('url'); ?>" method="get">
<select name="page_id" id="page_id">
<?php
global $post;
$args = array( 'numberposts' => -1);
$posts = get_posts($args);
foreach( $posts as $post ) : setup_postdata($post); ?>
               <option value="<? echo $post->ID; ?>"><?php the_title(); ?></option>
<?php endforeach; ?>
</select>
<input type="submit" name="submit" value="view" />
</form>
<script>
jQuery(document).ready(function () {
 jQuery('.js-category-button').on('click', function(e){
  e.preventDefault();
  var catID = jQuery(this).data('slug');
  var ajaxurl = 'http://localhost/wordpressdemo/wp-admin/admin-ajax.php';
    jQuery.ajax({
        type: 'POST',
        url: ajaxurl,
        crossDomain : true,
        dataType: 'html',
        data: {"action": "load-filter", cat: catID },
        beforeSend: function () {
            jQuery(".the-news").html('<p></p>')
        },
        success: function(response) {
            jQuery(".the-news").append(response);
            return false;
        }
    });
})

}); 
</script>
<style>

li {
    display: inline; /* or 'inline-block' */
}
</style>
<?php get_footer(); ?>