<div class="container-fluid pad_0">
	<div class="navbar-header" id="archive-browser">
		<div style="width: 150px;float:left;">
		  <?php
		  $categories = get_categories('taxonomy=program-video&hide_empty=0'); 
		  ?>
		  <select name="cat" id="program" class="postform" >
		  	<option value="">Any Program</option>
			    <?php
		    	foreach($categories as $category)
			  	{ 
			  	?>
			        <option value= <?php echo $category->term_id ?> > 
			        	<?php echo $category->name ?>
			        </option>";
			        <?php
				}
			  ?>
		  </select>
		</div>
		<div style="width: 150px;float:left;">
			  <?php
			  $categories = get_categories('taxonomy=workout&hide_empty=0'); 
			  ?>
			  <select name="cat" id="time" class="postform" >
			  <option value="">Any Time</option>
				  <?php
				  foreach($categories as $category)
					  { 
					  ?>
					        <option value= <?php echo $category->term_id ?> > 
					        	<?php echo $category->name ?>
					        </option>";
					        <?php
					  }
				  ?>
			  </select>
		</div>
		<div style="width: 150px;float:left;">
			  <?php
			  $categories = get_categories('taxonomy=difficulty&hide_empty=0'); 
			  ?>
			  <select name="cat" id="difficulty" class="postform" >
			  <option value="">Any Difficulty</option>
				  <?php
				  foreach($categories as $category)
					  { 
					  ?>
					        <option value= <?php echo $category->term_id ?> > 
					        	<?php echo $category->name ?>
					        </option>";
					        <?php
					  }
				  ?>
			  </select>
		</div>
		<div style="width: 150px;float:left;">
			<!-- <h4>Trainer</h4>-->
			  <?php
			  $categories = get_categories('taxonomy=trainer&hide_empty=0'); 
			  ?>
			  <select name="cat" id="trainer" class="postform" >
			  <option value="">Any Trainer</option>
				  <?php
				  foreach($categories as $category)
					  { 
					  ?>
					        <option value= <?php echo $category->term_id ?> > 
					        	<?php echo $category->name ?>
					        </option>";
					        <?php
					  }
				  ?>
			  </select>
		</div>
	</div>	 
</div>