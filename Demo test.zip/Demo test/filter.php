<?php
/* Template Name: Post listing123*/ 


?>
<?php get_header(); ?><br />

<div id="ajax-cases">
<?php
// WP Query
$args = array(
'post_type' => 'post',
'post_status' => 'publish',
'nopaging' => true, // show all posts in one go
);
$query = new WP_Query( $args );
$tax = 'category';
$terms = get_terms( $tax, $args);
$count = count( $terms );
if ( $count > 0 ): ?>
<div class="post-tags">
<?php
echo '<select>';
foreach ( $terms as $term ) {
$term_link = get_term_link( $term, $tax ); 
echo '<option value="' . $term_link . '" class="tax-filter" title="'.$term->slug.'">' . $term->name . '</option> ';
}
echo '</select>';?>
</div>
<?php endif; ?>
</div>
<div class="tagged-posts">
//result must display here
</div>
<script>
jQuery(document).ready(function(jQuery) {
jQuery('.post-tags select').on('change', function(event) {


// Prevent default action - opening tag page
if (event.preventDefault) {
    event.preventDefault();
} else {
    event.returnValue = false;
}

// Get tag slug from title attirbute
var selecetd_taxonomy = jQuery(this).find('option:selected').attr("title");

// After user click on tag, fade out list of posts
jQuery('.tagged-posts').fadeOut();

data = {
    action: 'filter_posts', // function to execute
    afp_nonce: afp_vars.afp_nonce, // wp_nonce
    taxonomy: selecetd_taxonomy, // selected tag
    };

jQuery.post( afp_vars.afp_ajax_url, data, function(response) {

    if( response ) {
    (response);
        // Display posts on page
        jQuery('.tagged-posts').html( response );
        // Restore div visibility
        jQuery('.tagged-posts').fadeIn();
    };
});
});
});
</script>
<?php

//---------------------Function.php-----------------
add_action( 'wp_ajax_filter_posts', 'ajax_filter_get_posts' );
add_action('wp_ajax_category_select_action', 'implement_ajax');
add_action('wp_ajax_nopriv_category_select_action', 'implement_ajax');//for users that are not logged in.

//this is optional, only if you are not already using jQuery  
function load_jquery() {
    wp_enqueue_script('jquery');            
}     
add_action('init', 'load_jquery');


function ajax_filter_posts_scripts() {
// Enqueue script
wp_register_script('afp_script', get_template_directory_uri() . '/js/ajax-filter-posts.js', false, null, false);
wp_enqueue_script('afp_script');

wp_localize_script( 'afp_script', 'afp_vars', array(
'afp_nonce' => wp_create_nonce( 'afp_nonce' ), // Create nonce which we later will use to verify AJAX request
'afp_ajax_url' => admin_url( 'admin-ajax.php' ),
)
);
}
add_action('wp_enqueue_scripts', 'ajax_filter_posts_scripts', 100);
function ajax_filter_get_posts( $taxonomy ) {

// Verify nonce
if( !isset( $_POST['afp_nonce'] ) || !wp_verify_nonce( $_POST['afp_nonce'], 'afp_nonce' ) )
die('Permission denied');

$taxonomy = $_POST['taxonomy'];

// WP Query
$args = array(

'post_type' => 'post',
'nopaging' => true, // show all posts in one go
);
//echo $taxonomy;
// If taxonomy is not set, remove key from array and get all posts
if( !$taxonomy ) {
unset( $args['tag'] );
}else{
// This is the code which you are missing. You need to add taxonomy query if taxonomy is set.
$arg['tax_query']= array(
array(
'taxonomy' => 'category',
'field' => 'slug',
'terms' => array( $taxonomy ),
'include_children' => true, // set true if you want post of its child     category also
'operator' => 'IN'
),
);
}

$query = new WP_Query( $args );

if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();

//$output  = '<h2><a href="'.get_permalink().'">'. get_the_title().'</a></h2>';
  $output = '<a href="' . get_the_permalink() . '">'. get_the_title() .'</a>';
    $output .=  get_the_content() ;
$output .= get_the_excerpt();

$result = 'success';

endwhile; else:
$output = '<h2>No posts found</h2>';
$result = 'fail';
endif;

$response = json_encode($output);
echo $response;
die();
}
?>
<?php get_footer(); ?>