</div><!-- /.row -->

</div><!-- /.container -->

<footer class="blog-footer">
    <p> Jaffar Choudhari</p>
    <!--<p><a href="#">Back to top</a></p>-->
</footer>
<?php wp_footer(); ?>
</body>
</html>
